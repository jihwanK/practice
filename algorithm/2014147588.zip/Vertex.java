public class Vertex {
    private int demand;

    public Vertex(int demand) {
        this.demand = demand;
    }

    public int getDemand() {
        return this.demand;
    }
}