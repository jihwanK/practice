#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <dirent.h>
#include <pthread.h>

#include <stdio.h>
#include <stdlib.h>

#include <string.h>

void run_count_files(char *path) {
	struct stat buf;
	struct dirent *dir;
	DIR *dp;

	int regular_count = 0;
	int directory_count = 0;
	int symbolic_count = 0;
	int totalsize = 0;

	dp = opendir(path);
	if (dp == NULL) {
		fprintf(stderr, "fail opendir()\n");
		exit(1);
	}
	//-------------------------------------


	//	struct dirent {
	//		ino_t          d_ino;       /* Inode number */
	//		off_t          d_off;       /* Not an offset; see below */
	//		unsigned short d_reclen;    /* Length of this record */
	//		unsigned char  d_type;      /* Type of file; not supported
	//																	 by all filesystem types */
	//		char           d_name[256]; /* Null-terminated filename */
	//	};


	/*
		 DT_BLK      This is a block device.

		 DT_CHR      This is a character device.

		 DT_DIR      This is a directory.

		 DT_FIFO     This is a named pipe (FIFO).

		 DT_LNK      This is a symbolic link.

		 DT_REG      This is a regular file.

		 DT_SOCK     This is a UNIX domain socket.

		 DT_UNKNOWN  The file type could not be determined.
	 */


	//	struct stat {
	//		dev_t     st_dev;         /* ID of device containing file */
	//		ino_t     st_ino;         /* inode number */
	//		mode_t    st_mode;        /* file type and mode */
	//		nlink_t   st_nlink;       /* number of hard links */
	//		uid_t     st_uid;         /* user ID of owner */
	//		gid_t     st_gid;         /* group ID of owner */
	//		dev_t     st_rdev;        /* device ID (if special file) */
	//		off_t     st_size;        /* total size, in bytes */
	//		blksize_t st_blksize;     /* blocksize for filesystem I/O */
	//		blkcnt_t  st_blocks;      /* number of 512B blocks allocated */




	chdir(path);
	while (dir = readdir(dp)) {
		if (dir->d_type	== DT_REG) {
			regular_count++;
			lstat(dir->d_name, &buf);
			totalsize += buf.st_size;
		} else if (dir->d_type == DT_DIR) {
			lstat(dir->d_name, &buf);
			if (strcmp(dir->d_name, ".") && strcmp(dir->d_name, ".."))
				directory_count++;
		} else if (dir->d_type == DT_LNK) {
			symbolic_count++;
		}
	}
	closedir(dp);
	chdir("..");






	//-------------------------------------

	printf("regular: %d\n", regular_count);
	printf("directory: %d\n", directory_count);
	printf("symbolic_count: %d\n", symbolic_count);
	printf("totalsize: %d\n", totalsize);
}

#define MSGSIZE 1024

void run_ls_and_save(char *dir) {
	pid_t pid;
	int fd = open("out.txt", O_WRONLY | O_CREAT| O_TRUNC);

	pid = fork();
	if (pid == 0) {
		//-------------------------------------

		char *argv[] = {"ls", "-l", dir};
		close(1);
		dup(fd);
		execve("/bin/ls", argv, 0);

		//-------------------------------------
		exit(1);
	}

	wait(0);
	printf("out.txt에 저장되었습니다.\n");
}

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
int total_word_count = 0;

void *word_count(void *arg) {
	char *filename = (char *)arg;
	FILE *fp;
	int ch;
	int flag = 0;

	fp = fopen(filename, "r");
	if (fp == NULL) {
		fprintf(stderr, "file open error..\n");
		exit(1);
	}
	while ((ch = fgetc(fp)) != EOF) {
		//-------------------------------------

		if ((ch != '\n') && (ch != ' ') && (ch != '\t')) {
			if (flag == 0) {
				pthread_mutex_lock(&mutex);	
				total_word_count++;
				pthread_mutex_unlock(&mutex);
				flag = 1;
			} 
		} else { 
				flag = 0;
		}


		//-------------------------------------
	}

	return 0;
}

void run_thread() {
	int i;

	pthread_t thread[3];
	pthread_create(&thread[0], NULL, word_count, "./testcase/wc1.txt");
	pthread_create(&thread[1], NULL, word_count, "./testcase/wc2.txt");
	pthread_create(&thread[2], NULL, word_count, "./testcase/wc3.txt");

	for (i = 0; i < 3; ++i) {
		pthread_join(thread[i], NULL);
	}

	printf("total word count: %d\n", total_word_count);
}

void print_usage() {
	printf("Usage: ./sample_run -1 or -2 or -3\n");
}

int main(int argc, char* argv[]) {
	int opt;

	if (argc == 1) {
		print_usage();
	}

	while ((opt = getopt(argc, argv, "123")) != -1) {
		switch (opt) {
			case '1':
				run_count_files("./testcase");
				break;
			case '2':
				run_ls_and_save("./testcase");
				break;
			case '3':
				run_thread();
				break;
		}

	}
}
