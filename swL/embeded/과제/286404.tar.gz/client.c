#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>

#include <wiringPi.h>
#include <mcp3422.h>


double celsius;
int cds;

void get_value()
{
	celsius = ((analogRead(401) / 1000.0) - 0.5) * 100;
	cds = analogRead(400);
}

int main()
{
	int sd; //socke_discriptor
	struct sockaddr_in addr;
	char buff[1024];
	int ret;

	int menu;

	
	/* setup the raspberry pi */
	if (wiringPiSetup() == -1)
		return -1;

	mcp3422Setup(400, 0x6a, 0, 0);
	/* finish setup */

	sd = socket(AF_INET, SOCK_STREAM, 0);

	memset(&addr, 0, sizeof(addr));
	addr.sin_family = AF_INET;
	addr.sin_port   = htons(7777);
	addr.sin_addr.s_addr    = inet_addr("192.168.137.100");

	connect(sd, (struct sockaddr*)&addr, sizeof(addr));

	while(1)
	{
		int conv;

		const int TEMP = 1;
		const int CDS = 2;
		int length;

		char *data;

		get_value();

		conv = htonl(TEMP);
		data = (char*)&conv;
		length = sizeof(conv);
		write(sd, &data, length);
		
		conv = htonl(sizeof(float));
		data = (char*)&conv;
		length = sizeof(conv);
		write(sd, &data, length);

		write(sd, &celsius, sizeof(celsius));

		conv = htonl(CDS);
		data = (char*)&conv;
		length = sizeof(conv);
		write(sd, &data, length);
		
		conv = htonl(sizeof(int));
		data = (char*)&conv;
		length = sizeof(conv);
		write(sd, &data, length);
		
		conv = htonl(cds);
		data = (char*)&conv;
		length = sizeof(conv);
		write(sd, &data, length);

		sleep(2);
	}

	close(sd);
}
